// OBEY COMMANDMENTS

global.prefa = ['','!','.',',','🐤','🗿'] //NOT CHANGE
global.owner = ['6282245186794'] //OWNER
global.botname = 'TexBotz' //BOT NAME
global.versisc = "4.4.4" //NOT CHANGE
global.baileys1 = require('@whiskeysockets/baileys') //NOT CHANGE
global.creator = "Tama_Ultraa" //NOT CHANGE
global.packname = "Sticker By" //OPSIONAL
global.author = "Tama_Ultraa" //OPSIONAL
global.simbol = "✇" // SIMBOL MENU